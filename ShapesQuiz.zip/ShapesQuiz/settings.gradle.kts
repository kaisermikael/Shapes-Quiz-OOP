
rootProject.name = "ShapesLibrary"

