class CompositeShape: Shape {
    var subShapes: ArrayList<Shape> = ArrayList()
        private set

    fun getShapeCount(): Int{
        return subShapes.size
    }

    fun addShape(newShape: Shape) {
        subShapes.add(newShape)
    }

    override fun calcArea(): Double {
        var totalArea = 0.0
        for (shape in subShapes) {
            totalArea += shape.calcArea()
        }
        return totalArea
    }

    override fun moveVertical(verticalDelta: Double) {
        for (shape in subShapes) {
            shape.moveVertical(verticalDelta)
        }
    }

    override fun moveHorizontal(horizontalDelta: Double) {
        for (shape in subShapes) {
            shape.moveHorizontal(horizontalDelta)
        }
    }

}