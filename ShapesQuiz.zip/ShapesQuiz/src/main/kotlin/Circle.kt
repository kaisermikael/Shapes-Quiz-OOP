import kotlin.math.sqrt

class Circle(center: Point, radius: Double) : Ellipse(center, radius, radius) {
}