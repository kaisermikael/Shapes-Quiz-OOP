import kotlin.random.Random

class ShapeFactory {

    val possibleShapes = listOf("point","line","rectangle","square","ellipse","circle","triangle","pentagon","npointstar","compositeshape")
    private val negativeRange = -10.1
    private val positiveRange = 10.1
    private val compositeShapeMax = 5

    fun createPoint(): Point {
        val randXCoord = Random.nextDouble(negativeRange, positiveRange)
        val randYCoord = Random.nextDouble(negativeRange, positiveRange)
        return Point(randXCoord, randYCoord)
    }

    fun createLine(): Line {
        val point1 = createPoint()
        val point2 = createPoint()
        if (point1.xValue == point2.xValue) {
            point1.moveXValue(1.0)
        }
        if (point1.yValue == point2.yValue) {
            point1.moveYValue(1.0)
        }
        return Line(point1, point2)
    }

    fun createRectangle(): Rectangle {
        val point1 = createPoint()
        val point2 = createPoint()
        if (point1.xValue == point2.xValue) {
            point1.moveXValue(1.0)
        }
        if (point1.yValue == point2.yValue) {
            point1.moveYValue(1.0)
        }
        return Rectangle(point1, point2)
    }

    fun createSquare(): Square {
        val point = createPoint()
        var width = Random.nextDouble(negativeRange, positiveRange)
        if (width == 0.0) {
            width = 1.0
        }
        return Square(point, width)
    }

    fun createEllipse(): Ellipse {
        val centerPoint = createPoint()
        var horizontalRadius = Random.nextDouble(0.0, positiveRange)
        val verticalRadius = Random.nextDouble(0.0, positiveRange)
        if (horizontalRadius == verticalRadius) {
            horizontalRadius++
        }
        return Ellipse(centerPoint, horizontalRadius, verticalRadius)
    }

    fun createCircle(): Circle {
        val centerPoint = createPoint()
        val radius = Random.nextDouble(0.1, positiveRange)
        return Circle(centerPoint, radius)
    }

    fun createTriangle(): Triangle {
        var newTriangle: Triangle
        val point1 = createPoint()
        val point2 = createPoint()
        val point3 = createPoint()
        try {
            newTriangle = Triangle(point1, point2, point3)
        } catch (exception: IllegalArgumentException) {
            // If it doesn't work the first time... try again :)
            newTriangle = createTriangle()
        }

        return newTriangle
    }

    fun createNPointStar(): NPointStar {
        val centerPoint = createPoint()
        val radius = Random.nextDouble(0.1, positiveRange)
        // Below 3 is impossible, above 8 is too difficult to calculate
        val pointCount = Random.nextInt(3, 9)
        return NPointStar(centerPoint, radius, pointCount)
    }

    fun createPentagon(): Pentagon {
        val centerPoint = createPoint()
        val radius = Random.nextDouble(0.1, positiveRange)
        return Pentagon(centerPoint, radius)
    }

    fun createCompositeShape(): CompositeShape {
        val newCompositeShape = CompositeShape()
        val numberOfShapes = Random.nextInt(1, compositeShapeMax)
        for (i in 1..numberOfShapes) {
            when (Random.nextInt(0, 7)) {
                0 -> {
                    newCompositeShape.addShape(createRectangle())
                }
                1 -> {
                    newCompositeShape.addShape(createSquare())
                }
                2 -> {
                    newCompositeShape.addShape(createEllipse())
                }
                3 -> {
                    newCompositeShape.addShape(createCircle())
                }
                4 -> {
                    newCompositeShape.addShape(createTriangle())
                }
                5 -> {
                    newCompositeShape.addShape(createNPointStar())
                }
                6 -> {
                    newCompositeShape.addShape(createPentagon())
                }
            }
        }
        return newCompositeShape
    }



}