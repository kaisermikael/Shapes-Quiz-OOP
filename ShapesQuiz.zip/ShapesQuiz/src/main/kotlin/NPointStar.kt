import kotlin.math.PI
import kotlin.math.sin

class NPointStar(center: Point, ngonRadius: Double, pointCount: Int): Shape {
    var center: Point
        private set
    var ngonRadius: Double
        private set
    var pointCount: Int
        private set

    init {
        this.center = center
        this.ngonRadius = ngonRadius
        this.pointCount = pointCount
    }

    override fun calcArea(): Double {
        //Area of center polygon: A= (n/2)*(r^2)*sin(((360/n)*PI)/180) --> r= circumradius, n= # of sides
        //Side length from circumradius: side= 2r*sin(((180/n)*PI)/180)
        //Find n-# of triangle-points: A= n*(.5(sideLength)(sideLength)) --> Assuming points are equilateral triangles
        val innerInRadians = ((360/pointCount)* PI)/180
        val innerNgonArea = (2.5*(ngonRadius*ngonRadius)* sin(innerInRadians))
        val pointInRadians = (((180/pointCount)* PI)/180)
        val sideLength = 2*ngonRadius* sin(pointInRadians)
        val singlePointArea = .5*sideLength*sideLength
        return (innerNgonArea + (singlePointArea*pointCount))
    }

    override fun moveVertical(verticalDelta: Double) {
        center.moveYValue(verticalDelta)
    }

    override fun moveHorizontal(horizontalDelta: Double) {
        center.moveXValue(horizontalDelta)
    }

}