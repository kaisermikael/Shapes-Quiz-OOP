import java.util.*
import kotlin.collections.ArrayList
import com.google.gson.*
import java.io.File

class Quiz {

    val shapeFactory = ShapeFactory()

    fun runQuiz() {
        var running: Boolean = true
        var results = mutableListOf<Triple<String, String, String>?>()
        var totalScore = 0

        while (running) {
            println("Welcome to the ShapesQuiz!")
            println("Below is a list of Shapes. Please enter all shapes you would like to be quizzed on:")

            val selectedShapes = receiveShapeInput()
            println("You have selected $selectedShapes to be quizzed on")

            val questionNumber = receiveQuestionNumberInput()
            println()

            for (i in 1..questionNumber) {
                println("Question ${i}:")
                results.add(createQuizQuestion(selectedShapes))
            }
            for (i in results) {
                if (i != null) {
                    if (i.second == i.third) {
                        totalScore++
                    }

                }
            }
            println("You got $totalScore out of $questionNumber questions correct!")

            println("Would you like your results in JSON or txt format?")
            val outputType = readLine()

            if (outputType != null) {
                outputResults(outputType, results.toList())
            }

            println("Your results have been output into the root of this project!")

            running = false
        }
    }

    private fun outputResults(outputType: String, results: List<Triple<String, String, String>?>) {
        val gson = GsonBuilder().setPrettyPrinting().create()

        if (outputType.lowercase() == "json") {
            var questionIndex = 0
            var formattedResults = mutableListOf<List<String>>()
            for (result in results) {
                var first: String = ""
                first += "Question ${questionIndex + 1}:"
                questionIndex++
                first += result?.first ?: "missing question"
                var second: String = ""
                second += "Correct Answer: "
                second += result?.second ?: "missing correct answer"
                var third: String = ""
                third += "User Answer: "
                third += result?.third ?: "missing user answer"
                formattedResults.add(listOf(first, second, third))
            }
            val jsonList: String = gson.toJson(formattedResults)
            File("quizResults.json").writeText(jsonList)
        } else {
            var questionIndex = 1
            var formattedResults = mutableListOf<String>()
            for (result in results) {
                var resultString: String = ""
                resultString += "\nQuestion $questionIndex:\n"
                questionIndex++
                resultString += result?.first ?: "missing question"
                resultString += "\nCorrect Answer: "
                resultString += result?.second ?: "missing correct answer"
                resultString += "\nUser's Answer: "
                resultString += result?.third ?: "missing user's answer"
                formattedResults.add(resultString)
            }

            var txtList: String = ""

            for (result in formattedResults) {
                txtList += result
            }
            File("quizResults.txt").writeText(txtList)
        }
    }

    private fun createQuizQuestion(selectedShapes: ArrayList<String>): Triple<String, String, String>? {

        val chosenShape = selectedShapes[(0 until selectedShapes.size).random()]

        val quizQuestionStrategies = mapOf<String, QuizQuestionStrategy>(
            Pair("point", PointQuestionStrategy()),
            Pair("line", LineQuestionStrategy()),
            Pair("rectangle", RectangleQuestionStrategy()),
            Pair("square", SquareQuestionStrategy()),
            Pair("ellipse", EllipseQuestionStrategy()),
            Pair("circle", CircleQuestionStrategy()),
            Pair("pentagon", PentagonQuestionStrategy()),
            Pair("npointstar", NPointStarQuestionStrategy()),
            Pair("compositeshape", CompositeShapeQuestionStrategy()),
        )

        return quizQuestionStrategies[chosenShape]?.createQuizQuestion(shapeFactory)
    }

    private fun receiveShapeInput(): ArrayList<String> {
        val selectedShapes = ArrayList<String>()
        println("(Not case-sensitive. Split by spaces) Example Input: > square rectangle compositeshape ")
        println("========Possible Shapes========")
        for (possibleShape in shapeFactory.possibleShapes) {
            println(possibleShape)
        }

        val userInput = readLine()!!.split(" ")
        for (s in userInput) {
            selectedShapes.add(s.lowercase(Locale.getDefault()))
        }
        return selectedShapes
    }

    private fun receiveQuestionNumberInput(): Int {
        println("How many questions would you like to receive?")
        val userInput = readLine()!!.split(" ")

        return userInput[0].toInt()
    }
}