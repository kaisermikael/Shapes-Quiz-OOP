import kotlin.random.Random

class TriangleQuestionStrategy: QuizQuestionStrategy {

    override fun createQuizQuestion(shapeFactory: ShapeFactory): Triple<String, String, String> {
        val triangle = shapeFactory.createTriangle()

        println("There is a triangle from (${triangle.point1.xValue},${triangle.point1.yValue}) to " +
                "(${triangle.point2.xValue},${triangle.point2.yValue}) to (${triangle.point3.xValue},${triangle.point3.yValue})")

            when (Random.nextInt(0, 4)) {
                0 -> {
                    val randX = Random.nextDouble(-5.0, 5.0)
                    val randY = Random.nextDouble(-5.0, 5.0)
                    val question = "If the ENTIRE triangle is moved horizontally by $randX and vertically by $randY, " +
                            "what are the new coordinates for the FIRST point? " +
                            "(Round down to nearest whole number. Separate by space.) (Ex. Answer: 12 -4 )"

                    val correctAnswer = "${triangle.point1.xValue.toInt()} ${triangle.point1.yValue.toInt()}"
                    val userAnswer = readLine()!!
                    return Triple(question, correctAnswer, userAnswer)
                }
                1 -> {
                    val randX = Random.nextDouble(-5.0, 5.0)
                    val randY = Random.nextDouble(-5.0, 5.0)
                    val question = "If the ENTIRE triangle is moved horizontally by $randX and vertically by $randY, " +
                            "what are the new coordinates for the SECOND point? " +
                            "(Round down to nearest whole number. Separate by space.) (Ex. Answer: 12 -4 )"

                    val correctAnswer = "${triangle.point2.xValue.toInt()} ${triangle.point2.yValue.toInt()}"
                    val userAnswer = readLine()!!
                    return Triple(question, correctAnswer, userAnswer)
                }
                2 -> {
                    val randX = Random.nextDouble(-5.0, 5.0)
                    val randY = Random.nextDouble(-5.0, 5.0)
                    val question = "If the ENTIRE triangle is moved horizontally by $randX and vertically by $randY, " +
                            "what are the new coordinates for the SECOND point? " +
                            "(Round down to nearest whole number. Separate by space.) (Ex. Answer: 12 -4 )"

                    val correctAnswer = "${triangle.point3.xValue.toInt()} ${triangle.point3.yValue.toInt()}"
                    val userAnswer = readLine()!!
                    return Triple(question, correctAnswer, userAnswer)
                }
                3 -> {
                    val question = "What is the area of the triangle? (Round down to nearest whole number) (Ex. Answer: 6)"
                    println(question)

                    val correctAnswer = "${triangle.calcArea().toInt()}"
                    val userAnswer = readLine()!!
                    return Triple(question, correctAnswer, userAnswer)
                }
            }
        return Triple("ERROR", "ERROR", "ERROR")
    }
}