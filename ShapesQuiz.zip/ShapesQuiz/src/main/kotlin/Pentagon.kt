import kotlin.math.PI
import kotlin.math.sin

class Pentagon(center: Point, radius: Double): Shape {

    var center: Point
        private set
    var radius: Double
        private set

    init {
        this.center = center
        this.radius = radius
    }

    override fun calcArea(): Double {
        //Area of a polygon: A= (n/2)*(r^2)*sin(((360/n)*PI)/180) --> r= circumradius, n= # of sides
        //Area of a pentagon: A= (5/2)*(r^2)*sin(((360/5)*PI)/180)
        val inRadians = ((360/5)* PI)/180
        return (2.5*(radius*radius)* sin(inRadians))
    }

    override fun moveVertical(verticalDelta: Double) {
        center.moveYValue(verticalDelta)
    }

    override fun moveHorizontal(horizontalDelta: Double) {
        center.moveXValue(horizontalDelta)
    }

}