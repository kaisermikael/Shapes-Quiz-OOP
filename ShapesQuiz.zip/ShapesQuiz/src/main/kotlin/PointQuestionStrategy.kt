import kotlin.random.Random

class PointQuestionStrategy: QuizQuestionStrategy {

    override fun createQuizQuestion(shapeFactory: ShapeFactory): Triple<String, String, String> {
        val point = shapeFactory.createPoint()

        println("There is a point at (${point.xValue},${point.yValue})")
        val randX = Random.nextDouble(-5.0, 5.0)
        val randY = Random.nextDouble(-5.0, 5.0)

        val question = "If the point is moved horizontally by $randX and vertically by $randY, " +
                "what are the new coordinates for the point? (Round down to nearest whole number. Separate by space.) (Ex. Answer: 12 -4 )"
        println(question)

        val correctAnswer = "${point.xValue.toInt()} ${point.yValue.toInt()}"
        val userAnswer = readLine()!!

        return Triple(question, correctAnswer, userAnswer)
    }
}