import kotlin.random.Random

class CircleQuestionStrategy: QuizQuestionStrategy {

    override fun createQuizQuestion(shapeFactory: ShapeFactory): Triple<String, String, String> {
        val circle = shapeFactory.createCircle()

        println("There is a circle centered at (${circle.center.xValue},${circle.center.yValue}) with radius ${circle.horizontalRadius}.")

            when (Random.nextInt(0, 2)) {
                0 -> {
                    val randX = Random.nextDouble(-5.0, 5.0)
                    val randY = Random.nextDouble(-5.0, 5.0)
                    val question = "If the ENTIRE circle is moved horizontally by $randX and vertically by $randY, " +
                            "what are the new coordinates for the center point? " +
                            "(Round down to nearest whole number. Separate by space.) (Ex. Answer: 12 -4 )"

                    val correctAnswer = "${circle.center.xValue.toInt()} ${circle.center.yValue.toInt()}"
                    val userAnswer = readLine().toString()
                    return Triple(question, correctAnswer, userAnswer)
                }
                1 -> {
                    val question = "What is the area of the circle? (Round down to nearest whole number) (Ex. Answer: 6)"
                    println(question)

                    val correctAnswer = "${circle.calcArea().toInt()}"
                    val userAnswer = readLine().toString()
                    return Triple(question, correctAnswer, userAnswer)
                }
            }
        return Triple("ERROR", "ERROR", "ERROR")
    }
}