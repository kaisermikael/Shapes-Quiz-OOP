interface Shape {
    fun calcArea(): Double
    fun moveVertical(verticalDelta: Double)
    fun moveHorizontal(horizontalDelta: Double)
}