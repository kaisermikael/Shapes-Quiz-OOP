fun main(args: Array<String>) {
    val quiz = Quiz()
    quiz.runQuiz()
}