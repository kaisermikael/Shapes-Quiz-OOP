import kotlin.random.Random

class LineQuestionStrategy: QuizQuestionStrategy {

    override fun createQuizQuestion(shapeFactory: ShapeFactory): Triple<String, String, String> {
        val line = shapeFactory.createLine()

        println("There is a line from (${line.point1.xValue},${line.point1.yValue}) to (${line.point2.xValue},${line.point2.yValue})")

            when (Random.nextInt(0, 4)) {
                0 -> {
                    val randX = Random.nextDouble(-5.0, 5.0)
                    val randY = Random.nextDouble(-5.0, 5.0)
                    val question = "If the ENTIRE line is moved horizontally by $randX and vertically by $randY, " +
                            "what are the new coordinates for the FIRST point? " +
                            "(Round down to nearest whole number. Separate by space.) (Ex. Answer: 12 -4 )"

                    val correctAnswer = "${line.point1.xValue.toInt()} ${line.point1.yValue.toInt()}"
                    val userAnswer = readLine()!!
                    return Triple(question, correctAnswer, userAnswer)
                }
                1 -> {
                    val randX = Random.nextDouble(-5.0, 5.0)
                    val randY = Random.nextDouble(-5.0, 5.0)
                    val question = "If the ENTIRE line is moved horizontally by $randX and vertically by $randY, " +
                            "what are the new coordinates for the SECOND point? " +
                            "(Round down to nearest whole number. Separate by space.) (Ex. Answer: 12 -4 )"

                    val correctAnswer = "${line.point2.xValue.toInt()} ${line.point2.yValue.toInt()}"
                    val userAnswer = readLine()!!
                    return Triple(question, correctAnswer, userAnswer)
                }
                2 -> {
                    val question = "What is the slope of the line? (Round down to nearest whole number) (Ex. Answer: 6)"
                    println(question)

                    val correctAnswer = "${line.calcSlope().toInt()}"
                    val userAnswer = readLine()!!
                    return Triple(question, correctAnswer, userAnswer)
                }
                3 -> {
                    val question = "What is the length of the line? (Round down to nearest whole number) (Ex. Answer: 6)"
                    println(question)

                    val correctAnswer = "${line.calcLength().toInt()}"
                    val userAnswer = readLine()!!
                    return Triple(question, correctAnswer, userAnswer)
                }
            }
        return Triple("ERROR", "ERROR", "ERROR")
    }
}