import kotlin.random.Random

class EllipseQuestionStrategy: QuizQuestionStrategy {

    override fun createQuizQuestion(shapeFactory: ShapeFactory): Triple<String, String, String> {
        val ellipse = shapeFactory.createEllipse()

        println("There is an ellipse centered at (${ellipse.center.xValue},${ellipse.center.yValue}) with horizontal radius " +
                "of ${ellipse.horizontalRadius} and vertical radius of ${ellipse.verticalRadius}.")

            when (Random.nextInt(0, 2)) {
                0 -> {
                    val randX = Random.nextDouble(-5.0, 5.0)
                    val randY = Random.nextDouble(-5.0, 5.0)
                    val question = "If the ENTIRE ellipse is moved horizontally by $randX and vertically by $randY, " +
                            "what are the new coordinates for the center point? " +
                            "(Round down to nearest whole number. Separate by space.) (Ex. Answer: 12 -4 )"

                    val correctAnswer = "${ellipse.center.xValue.toInt()} ${ellipse.center.yValue.toInt()}"
                    val userAnswer = readLine()!!
                    return Triple(question, correctAnswer, userAnswer)
                }
                1 -> {
                    val question = "What is the area of the ellipse? (Round down to nearest whole number) (Ex. Answer: 6)"
                    println(question)

                    val correctAnswer = "${ellipse.calcArea().toInt()}"
                    val userAnswer = readLine()!!
                    return Triple(question, correctAnswer, userAnswer)
                }
            }
        return Triple("ERROR", "ERROR", "ERROR")
    }
}