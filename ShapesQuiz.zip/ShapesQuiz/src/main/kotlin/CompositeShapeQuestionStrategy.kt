class CompositeShapeQuestionStrategy: QuizQuestionStrategy {

    override fun createQuizQuestion(shapeFactory: ShapeFactory): Triple<String, String, String> {
        val compositeShape = shapeFactory.createCompositeShape()

        println("There is a Composite Shape made up of the following shapes:")
        for (shape in compositeShape.subShapes) {
            println(shape.javaClass.name)
        }

        val question = "How many shapes are in this composite shape?"
        println(question)

        val correctAnswer = "${compositeShape.getShapeCount()}"
        val userAnswer = readLine().toString()
        return Triple(question, correctAnswer, userAnswer)
    }
}