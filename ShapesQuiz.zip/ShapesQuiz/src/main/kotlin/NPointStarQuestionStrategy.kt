import kotlin.random.Random

class NPointStarQuestionStrategy: QuizQuestionStrategy {

    override fun createQuizQuestion(shapeFactory: ShapeFactory): Triple<String, String, String> {
        val npointStar = shapeFactory.createNPointStar()

        println("There is a Star with ${npointStar.pointCount} points centered at (${npointStar.center.xValue},${npointStar.center.yValue}) with an inner radius of ${npointStar.ngonRadius}.")

            when (Random.nextInt(0, 2)) {
                0 -> {
                    val randX = Random.nextDouble(-5.0, 5.0)
                    val randY = Random.nextDouble(-5.0, 5.0)
                    val question = "If the ENTIRE npointStar is moved horizontally by $randX and vertically by $randY, " +
                            "what are the new coordinates for the center point? " +
                            "(Round down to nearest whole number. Separate by space.) (Ex. Answer: 12 -4 )"

                    val correctAnswer = "${npointStar.center.xValue.toInt()} ${npointStar.center.yValue.toInt()}"
                    val userAnswer = readLine()!!
                    return Triple(question, correctAnswer, userAnswer)
                }
                1 -> {
                    val question = "What is the area of the npointStar? (Round down to nearest whole number) (Ex. Answer: 6)"
                    println(question)
                    println("(Assumes the points are equilateral triangles)")

                    val correctAnswer = "${npointStar.calcArea().toInt()}"
                    val userAnswer = readLine()!!
                    return Triple(question, correctAnswer, userAnswer)
                }
            }
        return Triple("ERROR", "ERROR", "ERROR")
    }
}