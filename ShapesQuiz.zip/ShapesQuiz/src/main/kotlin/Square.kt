class Square(point1: Point, width: Double) : Rectangle(point1, Point(point1.xValue + width, point1.yValue + width)) {
}