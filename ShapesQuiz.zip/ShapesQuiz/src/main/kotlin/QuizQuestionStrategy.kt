interface QuizQuestionStrategy {
    fun createQuizQuestion(shapeFactory: ShapeFactory): Triple<String, String, String>
}