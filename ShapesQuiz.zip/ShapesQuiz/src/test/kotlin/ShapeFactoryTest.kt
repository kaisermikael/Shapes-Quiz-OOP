import org.junit.jupiter.api.Test

import org.junit.jupiter.api.Assertions.*

internal class ShapeFactoryTest {

    @Test
    fun getPossibleShapes() {
        val shapeFactory = ShapeFactory()
        assertEquals(shapeFactory.possibleShapes, listOf("point","line","rectangle","square","ellipse","circle","triangle","pentagon","npointstar","compositeshape"))
    }

    @Test
    fun createPoint() {
        val shapeFactory = ShapeFactory()
    }

    @Test
    fun createLine() {
        val shapeFactory = ShapeFactory()
    }

    @Test
    fun createRectangle() {
        val shapeFactory = ShapeFactory()
    }

    @Test
    fun createSquare() {
    }

    @Test
    fun createEllipse() {
    }

    @Test
    fun createCircle() {
    }

    @Test
    fun createTriangle() {
    }

    @Test
    fun createNPointStar() {
    }

    @Test
    fun createPentagon() {
    }

    @Test
    fun createCompositeShape() {
    }
}